# Role Name hv_manage_vm

This role is used to manage Windows and RHEL virtual machines in hyper-v server

## Role variables
See [openapi.yml](openapi.yml)

## Example workflow
```

```
vmtemplate create
```
# Extra vars:
# rl_hv_manage_vm_artifactoryurl: "<url>"
# rl_hv_manage_vm_templatename: "<templetename>"
# rl_hv_manage_vm_destinationpath: "<destination path>"
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vmtemplate_create.yml
      tags: template_create

```   
vmtemplate delete
```
# Extra vars:
# rl_hv_manage_vm_templatename: "<templetename>"
# rl_hv_manage_vm_destinationpath: "<destination path>"
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vmtemplate_delete.yml
      tags: template_delete

```      
vm_create  
```
# Extra vars:
# rl_hv_manage_vm_hostname: "<hyperv server name or cluster name in CMDB>"
# rl_hv_manage_vm_activedirectoryjoin: "<true/false>"
# rl_hv_manage_vm_amount: "<number of VMs to be created>"
# rl_hv_manage_vm_artifactory_vmtemplateurl: "<artifactory URL for VM creation template>"
# rl_hv_manage_vm_automaticstart: "<enable or disable automatic start>"
# rl_hv_manage_vm_baseimage: "<baseimage name>"
# rl_hv_manage_vm_component: "<virtual server component in CMDB>"
# rl_hv_manage_vm_disks:
#  - name: "<name of the disk>"
#    identifier: "<identifier for the disk>"
#    number: "<disk number>"
#    size: "<size of the disk in GB>"
#    filesystem: "<filesystem type>"
# rl_hv_manage_vm_dns: "<IP address for DNS server>"
# rl_hv_manage_vm_domain: "<name of the domain to add the VM>"
# rl_hv_manage_vm_domain_user: "<domain administrator username>"
# rl_hv_manage_vm_enable_vlan: "<true/false>"
# rl_hv_manage_vm_generation: "<vm generation>"
# rl_hv_manage_vm_highavailability: "<true/false>"
# rl_hv_manage_vm_is_virtual_appliance: "<true/false>"
# rl_hv_manage_vm_network: "<l3 network name in CMDB>"
# rl_hv_manage_vm_oneidentity_platform_id: "<oneidentity platform id>"
# rl_hv_manage_vm_operatingsystem: "<name of the operatins system as mentioned in CMDB>"
# rl_hv_manage_vm_os_version: "<version number of the os disk>"
# rl_hv_manage_vm_profile: "<profile for the vm>"
# rl_hv_manage_vm_region: "<region name for the vm>"
# rl_hv_manage_vm_role: "<virtual server role as per CMDB>"
# rl_hv_manage_vm_switchname: "<virtual switch name>"
# rl_hv_manage_vm_templatepath: "<template disk path in hyperv server>"
# rl_hv_manage_vm_timezone: "<timezone for the vm>"
# rl_hv_manage_vm_tshirtsize: "<tshirt size>"
# rl_hv_manage_vm_vlan: "<vlan id as per CMDB>"
# rl_hv_manage_vm_rhel_local_user: "<rhel local user>"
# rl_hv_manage_vm_windows_local_user: "<windows local user>"
# validate_certs: "<true/false>"
# onei_primary_ip: "<oneidentity ip address>"
# onei_username: "USERNAME"
# onei_password: "PASSWORD"
# cmdb_url: "<cmdb url>"
# cmdb_username: "USERNAME"
# cmdb_password: "PASSWORD"
# satellite_url: "<satellite url>"
# satellite_username: "USERNAME"
# satellite_password: "PASSWORD"
# satellite_environment: "<satellite environment>"
# satellite_orgid: "<satellite organization id>"
# rl_hv_manage_vm_oneidentity_windows_platform_id: "<oneidentity windows platform id>"
# rl_hv_manage_vm_oneidentity_linux_platform_id: "<oneidentity linux platform id>"
# rl_hv_manage_vm_oneidentity_policy_name: "<oneidentity policy name>"
# rl_hv_manage_vm_oneidentity_role_name: "<oneidentity role name>"
# rl_hv_manage_vm_dns_services: "<dns service name or ip address>"
# rl_hv_manage_vm_dns_zone: "<dns zone name or ip address>"
# rl_hv_manage_vm_mac_addr: "<initial mac address>"
# rl_hv_manage_vm_nktport_active: "<is_active status for network_port>"
# rl_hv_manage_vm_os_disk_size: "<os disk size>"
# rl_hv_manage_vm_capacity_unit: "<unit of measurement for disk size>"
# rl_hv_manage_vm_vif_speed: "<Transfer speed assigned to the port>"
# rl_hv_manage_vm_vif_mtu: "<maximum transmission unit, largest packet/frame that can be sent accross>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vm_create.yml
      tags: create

```   
vm_get.yml
```
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vm_get.yml
      tags: get

```   
vm_update
```
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"
# cmdb_url: "<cmdb url>"
# cmdb_username: "<cmdb username>"
# cmdb_password: "<cmdb password>"
# rl_hv_manage_vm_tshirt_profile: "<cpu/gpu tshirt profile>"
# rl_hv_manage_vm_tshirtsize:  "<tshirt size name>"
# rl_hv_manage_vm_vmname: "<vm name>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vm_update.yml
      tags: update
```   
vm_poweroff  
```
# Extra vars:
# rl_hv_manage_vm_vmname: "<vm name>"
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vm_poweroff.yml
      tags: poweroff

```   
vm_poweron
```
# Extra vars:
# rl_hv_manage_vm_vmname: "<vm name>"
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"

- name: Manage HyperV virtual machine
  hosts: all
  tasks:
    - block:
        - include_role:
            name: hv_manage_vm
            tasks_from: vm_poweron.yml
      tags: poweron

```   
vm_delete
```
# Extra vars:
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"
# cmdb_url: "<cmdb url>"
# cmdb_username: "<cmdb username>"
# cmdb_password: "<cmdb password>"
# rl_hv_manage_vm_vmname: "<vm name>"
# rl_hv_manage_vm_component: "<component>"
# rl_hv_manage_vm_cluster: "<cluster name>"
# rl_hv_manage_vm_cluster_disk_path: "<cluster disk path>"

  - name: Manage HyperV virtual machine
    hosts: all
    tasks:
      - block:
          - include_role:
              name: hv_manage_vm
            tasks_from: vm_delete.yml
        tags: delete
```   

vm_add_nics
```
# Extra vars:
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"
# cmdb_url: "<cmdb url>"
# cmdb_username: "<cmdb username>"
# cmdb_password: "<cmdb password>"
# rl_hv_manage_vm_nic_config:
#   - l3_name: "< name >"
      type: <dhcp | static>
      vlanId: <number>                                                                                                                       
      routing: <true | false>

  - name: Manage HyperV virtual machine
    hosts: all
    tasks:
      - block:
          - include_role:
              name: hv_manage_vm
              tasks_from: vm_add_nics.yml
```
vm_move

```
# Extra vars:
# onei_primary_ip: "<one identity primary ipaddressv4>"
# onei_username: "<one identity username>"
# onei_password: "<one identity password>"
# validate_certs: "< true or false>"
# cmdb_url: "<cmdb url>"
# cmdb_username: "<cmdb username>"
# cmdb_password: "<cmdb password>"
# rl_hv_manage_vm_vmname: "<vm name>"
# rl_hv_manage_vm_component: "<component>"
# rl_hv_manage_vm_service_type: "<service_type_for_cmdb>"
# rl_hv_manage_export_cluster_ip: "<ip_export_cluster>"
# rl_hv_manage_import_cluster_ip: "<ip_import_cluster>"
# rl_hv_manage_export_cluster_name: "<name_export_cluster_for_delete_VM>
# rl_hv_manage_import_cluster_name: "<name_import_cluster_for_cmdb>"
# rl_hv_manage_import_ansible_user: "<ansible_user_for_import_cluster>"
# rl_hv_manage_export_ansible_user: "<ansible_user_for_export_cluster>"
# rl_hv_manage_import_path: "<import_path_on_import_cluster>"
# rl_hv_manage_export_path: "<export_path_on_export_cluster>"
# rl_hv_manage_drive_letter: "<drive_letter_on_export_cluster_for_copy>"
# rl_hv_manage_import_network_adapter: "<network_adapter_name_for_import_cluster>"
# rl_hv_manage_import_network_adapter_vlan: "<VLAN_no.>"
# rl_hv_manage_import_vm_network: "<Layer3_network_name>"
# rl_hv_manage_import_vm_network_lease: "<static_or_DHCP>"
# rl_hv_manage_import_cluster_priority: "<cluster_priority>"

  - name: Manage HyperV virtual machine
    hosts: all
    tasks:
      - block:
          - include_role:
              name: hv_manage_vm
            tasks_from: vm_move.yml
        tags: vm_move
```


## Molecule tests

### Running the molecule tests
```bash
git clone https://<GITLAB>/arc-components/application/security/identity-access-mgmt/interfaces/iamuser_manage
git clone https://<GITLAB>/arc-components/application/security/identity-access-mgmt/interfaces/iamasset_manage.git
git clone https://<GITLAB>/arc-components/ztp/seed-cmdb/interfaces/cmdb_login.git
git clone https://<GITLAB>/arc-components/ztp/seed-cmdb/interfaces/cmdb_get.git
git clone https://<GITLAB>/arc-components/ztp/seed-cmdb/interfaces/cmdb_put.git
git clone https://<GITLAB>/arc-components/ztp/seed-cmdb/interfaces/cmdb_post.git
git clone https://<GITLAB>/arc-components/ztp/seed-cmdb/interfaces/cmdb_delete.git
git clone https://<GITLAB>/arc-components/application/security/aaa/roles/dns_record_manage.git
git clone https://<GITLAB>/arc-components/application/security/aaa/roles/ad_memberjoin.git
git clone  https://<GITLAB>/arc-components/infrastructure/virtual-computing/hypervisor/roles/hv_manage_vm
# Only required for testing
python3 -m venv dev_py3
. ~/dev_py3/bin/activate
cd hv_manage_vm
```
### Pre-requisite
```bash
In order to run all test scenarios, you will need to satisfy below requirements,

1. A standalone Hyper-V server
2. Template should be downloaded in correct path
3. SET switch must be created
4. CMDB URL must be accessible
5. Valid network name in CMDB must be provided
6. Only for vm_move, the VM must be already created on the export cluster and added to the CMDB;
```

# Run a specific test scenario
## Edit the scenario's molecule.yml file, replacing all the < tags  >
```bash
molecule test --scenario-name <scenario_name>
ansible_user: "<winrm username>"
ansible_port: "<winrm port>"
name: "<molecule server ipaddress/name>"

```
```
### This role implements the following tests for managing VM in hyper-v server :
* vm_create(Default)
* vm_delete
* vm_get
* vm_poweroff
* vm_poweron
* vm_update
* vmtemplate_create
* vmtemplate_delete
* vm_add_nics
* vm_move
