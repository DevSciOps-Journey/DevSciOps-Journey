#!/bin/bash
toaddr() {
    b1=$(( ($1 & 0xFF000000) >> 24))
    b2=$(( ($1 & 0xFF0000) >> 16))
    b3=$(( ($1 & 0xFF00) >> 8))
    b4=$(( $1 & 0xFF ))
    eval "$2=\$b1.\$b2.\$b3.\$b4"
}

if [[ $1 =~ ^([0-9\.]+)/([0-9]+)$ ]]; then
    # CIDR notation
    IPADDR=${BASH_REMATCH[1]}
    NETMASKLEN=${BASH_REMATCH[2]}
    zeros=$((32-NETMASKLEN))
    NETMASKNUM=0
    for (( i=0; i<$zeros; i++ )); do
        NETMASKNUM=$(( (NETMASKNUM << 1) ^ 1 ))
    done
    NETMASKNUM=$((NETMASKNUM ^ 0xFFFFFFFF))
    toaddr $NETMASKNUM NETMASK
fi
printf "$NETMASK"
