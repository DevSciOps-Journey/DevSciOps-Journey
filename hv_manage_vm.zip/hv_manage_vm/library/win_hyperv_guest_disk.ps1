#!powershell

#Requires -Module Ansible.ModuleUtils.Legacy

$params = Parse-Args $args;
$result = @{};
Set-Attr $result "changed" $false;

$diskpath = Get-Attr -obj $params -name diskpath
$size = Get-Attr -obj $params -name size

$state = Get-Attr -obj $params -name state -default "present"

if ("present", "absent", "resize" -notcontains $state) {
  Fail-Json $result "The state: $state doesn't exist; State can only be: present, resize, or absent"
}

Function Disk-Create {
  #Check If the disk already exists
  $Checkdisk = Get-VHD -Path "$diskpath" -ErrorAction SilentlyContinue

  if (!$Checkdisk) {
    $cmd = "New-VHD -Path '$diskpath' -SizeBytes $size"

      $results = invoke-expression $cmd
      $result.changed = $true
      } else {
        $result.changed = $false
      }
    }

 Function Disk-Resize {
     #Check If the disk already exists
     $CheckDisk = Get-VHD -Path "$diskpath" -ErrorAction SilentlyContinue

    if (!$Checkdisk) {
      $cmd = "Resize-VHD -Path '$diskpath' -SizeBytes $size"

      $results = invoke-expression $cmd
      $result.changed = $true
       } else {
        $result.changed = $false
        }
    }

    Function Disk-Delete {
      $CheckDisk = Get-VHD -Path "$diskpath" -ErrorAction SilentlyContinue

      if ($CheckDisk) {
        $cmd="Remove-item -Path '$diskpath' -Force"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         $result.changed = $false
       }
     }

     Try {
      switch ($state) {
        "present" {Disk-Create}
        "absent" {Disk-Delete}
        "resize" {Disk-Resize}
      }

      Exit-Json $result;
      } Catch {
        Fail-Json $result $_.Exception.Message
      }
Exit-Json -Obj $result
