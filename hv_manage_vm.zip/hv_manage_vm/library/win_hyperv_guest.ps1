#!powershell

#Requires -Module Ansible.ModuleUtils.Legacy

$params = Parse-Args $args;
$result = @{};
Set-Attr $result "changed" $false;

$name = Get-Attr -obj $params -name name -failifempty $true -emptyattributefailmessage "missing required argument: name"
$cpu = Get-Attr -obj $params -name cpu -default '1'
$memory = Get-Attr -obj $params -name memory -default '512MB'
$hostserver = Get-Attr -obj $params -name hostserver
$generation = Get-Attr -obj $params -name generation -default 2
$network_switch = Get-Attr -obj $params -name network_switch -default $null
$automaticstart = Get-Attr -obj $params -name automaticstart

$templatepath = Get-Attr -obj $params -name templatepath -default $null
$baseimage = Get-Attr -obj $params -name baseimage -default $null

$showlog = Get-Attr -obj $params -name showlog -default "false" | ConvertTo-Bool
$state = Get-Attr -obj $params -name state -default "present"
$profile = Get-Attr -obj $params -name profile -default $null
$path = Get-Attr -obj $params -name path -default $null
$vlan = Get-Attr -obj $params -name vlan -default $null

if ("poweron", "poweroff", "present", "absent", "update", "reboot","shutdown" -notcontains $state) {
  Fail-Json $result "The state: $state doesn't exist; State can only be: shutdown, present, update, absent, poweron or poweroff"
}

Function VM-Create {
  #Check If the VM already exists
  $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

  if (!$CheckVM) {
    $cmd = "New-VM -Name $name"

    if ($memory) {
      $cmd += " -MemoryStartupBytes $memory"
    }

    if ($hostserver) {
      $cmd += " -ComputerName $hostserver"
    }

    if ($generation) {
      $cmd += " -Generation $generation"
    }

    if ($network_switch) {
      $cmd += " -SwitchName '$network_switch'"
    }

    if ($templatepath) {
      $cmd += " -VHDPath '$templatepath'"
    }
    
    if ($path) {
      $cmd += " -Path '$path'"
    }
    if ($profile) {

      if ($profile -eq "bronze") {
          $reserve = 0
          $weight = 1
      }
      elseif ($profile -eq "silver") {
          $reserve = 25
          $weight = 33
      }
      elseif ($profile -eq "gold") {
          $reserve = 33
          $weight = 66
      }
      elseif ($profile -eq "platinum") {
          $reserve = 40
          $weight = 100
      }
    }

      # Need to chain these
      $results = invoke-expression $cmd
      $results = invoke-expression "Set-VMProcessor $name -Count $cpu -Reserve $reserve -RelativeWeight $weight"
      $results = invoke-expression "Set-VM $name -AutomaticStartAction $automaticstart"
      if ($vlan) {
      $results = invoke-expression "Set-VMNetworkAdapterVlan -VMName $name -Access -VlanId $vlan"      
      }
	
    if ($baseimage.Contains('Rhel')) {
      
      if ($generation -eq 2) {
         $results = invoke-expression "Set-VMFirmware $name -EnableSecureBoot on -SecureBootTemplate 'MicrosoftUEFICertificateAuthority'"
       }
    }
      $result.changed = $true
      } else {
        $result.changed = $false
      }
    }

 Function VM-Update {
     #Check If the VM already exists
     $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

    if ($CheckVM) {
      $cmd = "Set-VM -Name $name"

     if ($memory) {
      $cmd += " -MemoryStartupBytes $memory"
     }

     if ($cpu) {
      $cmd += " -ProcessorCount $cpu"
     }

      $results = invoke-expression $cmd
      $result.changed = $true
       } else {
        $result.changed = $false
        }
    }

    Function VM-Delete {
      $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

      if ($CheckVM) {
        $cmd="Remove-VM -Name $name -Force"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         $result.changed = $false
       }
     }


     Function VM-Poweron {
      $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

      if ($CheckVM) {
        $cmd="Start-VM -Name $name -PassThru"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         Fail-Json $result "The VM: $name; Doesn't exists please create the VM first"
       }
     }

    Function VM-Shutdown {
      $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

      if ($CheckVM) {
        $cmd="Stop-VM -Name $name -Passthru"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         Fail-Json $result "The VM: $name; Doesn't exists please create the VM first"
       }
     }


     Function VM-Poweroff {
      $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

      if ($CheckVM) {
        $cmd="Stop-VM -Name $name -TurnOff -Passthru"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         Fail-Json $result "The VM: $name; Doesn't exists please create the VM first"
       }
     }

    Function VM-Reboot {
      $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue

      if ($CheckVM) {
        $cmd="Restart-VM -Name $name -Force"
        $results = invoke-expression $cmd
        $result.changed = $true
        } else {
         Fail-Json $result "The VM: $name; Doesn't exists please create the VM first"
       }
     }

     Try {
      switch ($state) {
        "present" {VM-Create}
        "absent" {VM-Delete}
        "update" {VM-Update}
        "poweron" {VM-Poweron}
        "poweroff" {VM-Poweroff}
        "shutdown" {VM-Shutdown}
        "reboot" {VM-Reboot}
      }

      Exit-Json $result;
      } Catch {
        Fail-Json $result $_.Exception.Message
      }
Exit-Json -Obj $result
