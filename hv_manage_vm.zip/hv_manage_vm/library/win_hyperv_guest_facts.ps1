#!powershell


#Requires -Module Ansible.ModuleUtils.Legacy

Set-StrictMode -Version 2.0

$result = @{
    changed = $false
    ansible_facts = @{
        ansible_win_hyperv_guest = @()
    }
}


try {
    $vms = Get-Vm
} catch {
    Fail-Json -obj $result -message "Failed to search the disks on the target: $($_.Exception.Message)"
}

foreach ($vm in $vms) {

$vm_info = @{}


        $vm_info.Name = $vm.Name
        $vm_info.Id = $vm.Id
        $vm_info.ProcessorCount = $vm.ProcessorCount
        $vm_info.Path = $vm.Path
        $vm_info.Generation = $vm.Generation
        $vm_info.MemoryStartup = $vm.MemoryStartup
        $vm_info.MemoryMinimum = $vm.MemoryMinimum
        $vm_info.MemoryMinimum = $vm.MemoryMinimum
        $vm_info.DynamicMemoryEnabled = $vm.DynamicMemoryEnabled
        $vm_info.IsClustered = $vm.IsClustered
        $vm_info.ConfigurationLocation = $vm.ConfigurationLocation
        $vm_info.Path = $vm.path
        $vm_info.CreationTime = $vm.CreationTime
        $vm_info.Status = $vm.Status
        $vm_info.CPUUsage = $vm.CPUUsage

$result.ansible_facts.ansible_win_hyperv_guest += $vm_info
}
# Return result
Exit-Json -obj $result
