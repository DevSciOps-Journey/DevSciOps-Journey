#!powershell

#Requires -Module Ansible.ModuleUtils.Legacy

$params = Parse-Args $args;
$result = @{};
Set-Attr $result "changed" $false;


$config_list = Get-Attr -obj $params -name config -failifempty $true -emptyattributefailmessage "missing required argument: config"
$name = Get-Attr -obj $params -name name -failifempty $true -emptyattributefailmessage "missing required argument: name"
$network_switch = Get-Attr -obj $params -name network_switch -failifempty $true -emptyattributefailmessage "missing required argument: network_switch"


Function Set-VMNetworkConfiguration {
  [CmdletBinding()]
  Param (
    [Parameter(Mandatory=$true,
     Position=1,
     ParameterSetName='DHCP',
     ValueFromPipeline=$true)]
    [Parameter(Mandatory=$true,
     Position=0,
     ParameterSetName='Static',
     ValueFromPipeline=$true)]
    [Microsoft.HyperV.PowerShell.VMNetworkAdapter]$NetworkAdapter,

    [Parameter(Mandatory=$true,
     Position=1,
     ParameterSetName='Static')]
    [String[]]$IPAddress=@(),

    [Parameter(Mandatory=$false,
     Position=2,
     ParameterSetName='Static')]
    [String[]]$Subnet=@(),

    [Parameter(Mandatory=$false,
     Position=3,
     ParameterSetName='Static')]
    [String[]]$DefaultGateway = @(),

    [Parameter(Mandatory=$false,
     Position=4,
     ParameterSetName='Static')]
    [String[]]$DNSServer = @(),

    [Parameter(Mandatory=$false,
     Position=0,
     ParameterSetName='DHCP')]
    [Switch]$Dhcp
    )

    $VM = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ComputerSystem' | Where-Object { $_.ElementName -eq $NetworkAdapter.VMName }
    $VMSettings = $vm.GetRelated('Msvm_VirtualSystemSettingData') | Where-Object { $_.VirtualSystemType -eq 'Microsoft:Hyper-V:System:Realized' }
    $VMNetAdapters = $VMSettings.GetRelated('Msvm_SyntheticEthernetPortSettingData') | where {$_.ElementName -eq $NetworkAdapter.Name}

    $NetworkSettings = @()
    foreach ($NetAdapter in $VMNetAdapters) {
        if ($NetAdapter.Address -eq $NetworkAdapter.MacAddress) {
            $NetworkSettings = $NetworkSettings + $NetAdapter.GetRelated("Msvm_GuestNetworkAdapterConfiguration")
        }
    }

    $NetworkSettings[0].IPAddresses = $IPAddress
    $NetworkSettings[0].Subnets = $Subnet
    if($DefaultGateway){
        $NetworkSettings[0].DefaultGateways = $DefaultGateway
    }
    if($DNSServer){
        $NetworkSettings[0].DNSServers = $DNSServer
    }    
    $NetworkSettings[0].ProtocolIFType = 4096

    if ($dhcp) {
        $NetworkSettings[0].DHCPEnabled = $true
    } else {
        $NetworkSettings[0].DHCPEnabled = $false
    }

    $Service = Get-WmiObject -Class "Msvm_VirtualSystemManagementService" -Namespace "root\virtualization\v2"
    $setIP = $Service.SetGuestNetworkAdapterConfiguration($VM, $NetworkSettings[0].GetText(1))

    if ($setip.ReturnValue -eq 4096) {
      $job=[WMI]$setip.job

        while ($job.JobState -eq 3 -or $job.JobState -eq 4) {
            start-sleep 1
            $job=[WMI]$setip.job
        }

        if ($job.JobState -eq 7) {
            write-host "Success"
        }
        else {
            $job.GetError()
        }
    } elseif($setip.ReturnValue -eq 0) {
        Write-Host "Success"
    }
}

Try {
    $CheckVM = Get-VM -name $name -ErrorAction SilentlyContinue
    
    foreach ($nicConfig in $config_list){
        if ("static", "dhcp" -notcontains $nicConfig.type) {
            $result['net1'] = $config_list[0]
            $result['net2'] = $config_list[1]
            Fail-Json $result "The type: $type doesn't exist; Type can only be: static, dhcp"
        }

        if ($CheckVM) {
            
            if($nicConfig.adapter_name){
                Add-VMNetworkAdapter -VMName $name -SwitchName $network_switch -Name $nicConfig.adapter_name
            } else {
                Add-VMNetworkAdapter -VMName $name -SwitchName $network_switch               
            }
            # set IP config
            $cmd = "Get-VMNetworkAdapter -VMName $name | Select-Object -Last 1 | "
            if ($nicConfig.type -eq 'dhcp' ) {
                $cmd1 = $cmd +  "Set-VMNetworkConfiguration -DHCP"
            }

            elseif ($nicConfig.type -eq 'static' ) { 
                $ip = $nicConfig.ip -replace '"', ''
                $netmask = $nicConfig.netmask -replace '"', ''  
                $cmd1 = $cmd + "Set-VMNetworkConfiguration -IPAddress $ip -Subnet $netmask "
                if ( $nicConfig.dns ){
                    $cmd1 += " -DNSServer $nicConfig.dns"
                }
                if ($nicConfig.gateway){
                    $nicConfig.gateway = $nicConfig.nicConfig.gateway -replace '"', ''
                    $cmd1 += " -DefaultGateway $gateway"
                }
            }

            invoke-expression $cmd1
            $result.new =  $cmd1
            $result.changed = $true
            
            # set VLAN
            if ($nicConfig.vlanId) {

                $cmd2 = $cmd + "Set-VMNetworkAdapterVlan -Access -VlanId $([int]$nicConfig.vlanId)"
                invoke-expression $cmd2
                $result.new =  $cmd2
                $result.changed = $true
            }

            $cmd3 = $cmd + "Set-VMNetworkAdapter -MacAddressSpoofing On"

            invoke-expression $cmd3
            $result.new =  $cmd3
            $result.changed = $true

        } else {
            $result.changed = $false
        }
    }

    Exit-Json $result;

} Catch {
    Fail-Json $result $_.Exception.Message
}
