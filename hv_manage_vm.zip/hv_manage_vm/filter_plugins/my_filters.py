#!/usr/bin/python
# -*- coding: utf-8 -*-


class FilterModule(object):

    def filters(self):
        return {
	    "nic_update": self.nic_update,
        "nic_add": self.nic_add,
	    "disk_update": self.disk_update
        }
	

    def nic_update(
        self,
	keys,
	macaddress,
        speed,
        mtu
        ):

        network_port = keys['properties']['network_port']

        if isinstance(network_port, list):
            for item_port in network_port:
                item_port["mac"] = macaddress
                item_port["speed"] = speed
                item_port["mtu"] = mtu
        return keys

    def nic_add(
        self,
        keys,
        nic_object
    ):

        network_port = keys['properties']['network_port']

        if isinstance(network_port, list):
            network_port.append(nic_object)

        return keys

    def disk_update(
        self,
	keys,
        capacity,
        capacity_unit
        ):

        drive = keys['properties']['drive']

        if isinstance(drive, list):
            for item_drive in drive:
                item_drive["capacity"] = capacity
                item_drive["capacity_unit"] = capacity_unit
        return keys
